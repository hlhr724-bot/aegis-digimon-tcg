import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, '/work/tools/bot-evolution')

from adapter import EvaluationConfig, HeuristicAdapter
from evidence import policy_hash
from paired_pilot_evidence import paired_pilot_evidence


def _save(path: Path, value: dict) -> None:
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def _audit_game(game: dict) -> None:
    result = game['result']
    expected = 0.5 if result.get('winnerSeat') is None else int(result['winnerSeat'] == game['task']['learnerSeat'])
    if game['valid'] is not True or game['score'] != expected or result['timedOut'] or result['reason'] in ('stalled', 'cancelled', 'turnLimit', 'unfinished'):
        raise RuntimeError('Game health or outcome audit failed')
    if result['errors'] or result['rejections'] or game['asynchronousRejections'] or result.get('projectionChecks', 0) <= 0:
        raise RuntimeError('Game execution or projection audit failed')
    if any(seat['inferenceFallbacks'] != dict(timeout=0, error=0) for seat in result['seats']):
        raise RuntimeError('Inference fallback cannot contribute evidence')


def main() -> None:
    source = Path('/input/chronomon-quarter-v1')
    output = Path('/output/chronomon-quarter-v1')
    protocol_bytes = (source / 'protocol.json').read_bytes()
    protocol = json.loads(protocol_bytes)
    if int(Path('/sys/fs/cgroup/memory.max').read_text()) != protocol['memoryLimitBytes'] or int(Path('/sys/fs/cgroup/memory.swap.max').read_text()) != protocol['swapLimitBytes']:
        raise RuntimeError('Require the fixed aggregate memory and swap limits')
    programs = {arm: json.loads((source / f'{arm}.json').read_text(encoding='utf-8')) for arm in ('candidate', 'control')}
    for arm, program in programs.items():
        if policy_hash(program) != protocol[f'{arm}PolicySha256']:
            raise RuntimeError(f'Changed {arm} policy')
    deployment_hash = hashlib.sha256(json.dumps(protocol['deploymentIdentity'], sort_keys=True).encode()).hexdigest()
    if deployment_hash != protocol['deploymentPolicySha256']:
        raise RuntimeError('Changed deployment identity')
    stages = protocol['stages']
    if set(stages[0]['opponents']) & set(stages[1]['opponents']) or set(stages[0]['seeds']) & set(stages[1]['seeds']):
        raise RuntimeError('Screening and confirmation must be disjoint')
    for stage in stages:
        if len(set(stage['seeds'])) != stage['seedBlocks'] or protocol['learnerDeck'] in stage['opponents'] or set(stage['opponents']) & set(protocol['excludedDiscoveryMatchups']):
            raise RuntimeError('Invalid fixed task population')
    descriptor = subprocess.run(['node', '--max-old-space-size=1024', 'apps/api/dist/bot/evolution/evaluateCli.js', '--describe'], check=True, capture_output=True, text=True, timeout=120)
    metadata = json.loads(descriptor.stdout)
    if metadata['engineSha256'] != protocol['engineSha256']:
        raise RuntimeError('Changed compiled engine')
    metadata['residualBatchSize'] = protocol['residualBatchSize']
    output.mkdir(exist_ok=True)
    pinned = output / 'protocol.json'
    if pinned.exists() and pinned.read_bytes() != protocol_bytes:
        raise RuntimeError('Cannot change a frozen comparison')
    pinned.write_bytes(protocol_bytes)
    _save(output / 'runner.json', dict(sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), python=sys.version))
    _save(output / 'worker-metadata.json', metadata)
    reports = {}
    started = time.monotonic()
    for stage in stages:
        stage_root = output / stage['name']
        stage_root.mkdir(exist_ok=True)
        tasks = []
        for index, seed in enumerate(stage['seeds']):
            opponent = stage['opponents'][index % len(stage['opponents'])]
            for seat, decks in ((0, [protocol['learnerDeck'], opponent]), (1, [opponent, protocol['learnerDeck']])):
                tasks.append(dict(seed=seed, learnerSeat=seat, decks=decks, opponent='heuristic', opponentProgram=programs['control']))
        adapter = HeuristicAdapter(EvaluationConfig(node='/usr/local/bin/node', worker=Path('/work/apps/api/dist/bot/evolution/evaluateCli.js'), run_dir=stage_root / 'games', engine_sha256=protocol['engineSha256'], simulations=1, timeout=protocol['timeoutSeconds'], workers=protocol['workers'], cache_dir=stage_root / 'cache'), metadata)
        results = {}
        for arm in ('control', 'candidate'):
            results[arm] = []
            for offset in range(0, len(tasks), 128):
                batch = adapter.evaluate(tasks[offset:offset + 128], {'heuristic': json.dumps(programs[arm])}).outputs
                for game in batch:
                    _audit_game(game)
                results[arm].extend(batch)
                progress = dict(status='running', stage=stage['name'], arm=arm, played=len(results[arm]), gamesPerArm=len(tasks), seconds=time.monotonic() - started, activated=False)
                _save(output / 'progress.json', progress)
                print(json.dumps(progress), flush=True)
        arms = {arm: dict(played=len(games), wins=sum(game['score'] == 1 for game in games), draws=sum(game['score'] == 0.5 for game in games), score=sum(game['score'] for game in games) / len(games)) for arm, games in results.items()}
        difference = sum(candidate['score'] - control['score'] for candidate, control in zip(results['candidate'], results['control'], strict=True)) / len(tasks)
        report = dict(arms=arms, difference=difference)
        if stage['name'] == 'screen':
            report.update(continued=report['difference'] >= stage['minimumDifferenceToContinue'], certification=False)
        else:
            report['evidence'] = paired_pilot_evidence(selected=results['candidate'], control=results['control'], alpha=protocol['alpha'], population=protocol['seedPopulation'])
        reports[stage['name']] = report
        _save(stage_root / 'result.json', report)
        if stage['name'] == 'screen' and not report['continued']:
            break
    confirmation = reports.get('confirmation')
    final = dict(status='completed' if confirmation is not None else 'stopped-after-screen', activated=False, accepted=confirmation is not None and confirmation['evidence']['accepted'], protocolSha256=hashlib.sha256(protocol_bytes).hexdigest(), deploymentPolicySha256=deployment_hash, candidatePolicySha256=policy_hash(programs['candidate']), controlPolicySha256=policy_hash(programs['control']), engineSha256=protocol['engineSha256'], stages=reports, seconds=time.monotonic() - started)
    _save(output / 'result.json', final)
    _save(output / 'progress.json', final)
    print(json.dumps(final), flush=True)


if __name__ == '__main__':
    main()
