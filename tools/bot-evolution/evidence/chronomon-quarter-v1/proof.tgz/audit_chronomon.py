import hashlib
import json
import math
from pathlib import Path
from statistics import variance


def main() -> None:
    root = Path('/output/chronomon-quarter-v1')
    source = Path('/input/chronomon-quarter-v1')
    if not (root / 'result.json').is_file():
        raise RuntimeError('The fixed comparison must finish before its audit')
    protocol_bytes = (root / 'protocol.json').read_bytes()
    if protocol_bytes != (source / 'protocol.json').read_bytes():
        raise RuntimeError('Frozen protocol differs from the source')
    protocol = json.loads(protocol_bytes)
    report = json.loads((root / 'result.json').read_text(encoding='utf-8'))
    assert report['status'] == 'completed' and report['activated'] is False
    assert report['protocolSha256'] == hashlib.sha256(protocol_bytes).hexdigest()
    assert report['engineSha256'] == protocol['engineSha256']
    screen, stage = protocol['stages']
    assert stage['name'] == 'confirmation'
    assert not set(screen['opponents']) & set(stage['opponents'])
    assert not set(screen['seeds']) & set(stage['seeds'])
    assert not set(stage['opponents']) & set(protocol['excludedDiscoveryMatchups'])
    assert report['stages']['screen']['continued'] is True
    assert report['deploymentPolicySha256'] == protocol['deploymentPolicySha256']
    stage_report = report['stages']['confirmation']
    games_per_arm = stage['seedBlocks'] * 2
    expected = {}
    control = json.loads((source / 'control.json').read_text(encoding='utf-8'))
    for index, seed in enumerate(stage['seeds']):
        decks = [protocol['learnerDeck'], stage['opponents'][index % len(stage['opponents'])]]
        for seat in (0, 1):
            expected[(seed, seat)] = dict(seed=seed, learnerSeat=seat, decks=decks if seat == 0 else decks[::-1], opponent='heuristic', opponentProgram=control)
    assert len(expected) == games_per_arm
    arms = {arm: {} for arm in ('control', 'candidate')}
    signatures = {arm: {} for arm in arms}
    hashes = {}
    duplicate_artifacts = 0
    policies = {protocol[f'{arm}PolicySha256']: arm for arm in arms}
    assert len(policies) == 2
    for path in sorted((root / 'confirmation/games').glob('*.json')):
        raw = path.read_bytes()
        game = json.loads(raw)
        assert game['policySha256'] in policies
        arm = policies[game['policySha256']]
        task = game['task']
        key = (task['seed'], task['learnerSeat'])
        assert key in expected and task == expected[key]
        assert game['engineSha256'] == protocol['engineSha256']
        assert game['status'] == 'played' and game['valid'] is True
        result = game['result']
        assert result['winnerSeat'] in (None, 0, 1)
        score = 0.5 if result['winnerSeat'] is None else int(result['winnerSeat'] == key[1])
        assert type(game['score']) in (int, float) and game['score'] == score
        assert result['timedOut'] is False
        assert result['reason'] not in ('stalled', 'cancelled', 'turnLimit', 'unfinished')
        assert not result['errors'] and not result['rejections'] and not game['asynchronousRejections']
        assert result['projectionChecks'] > 0
        assert all(seat['inferenceFallbacks'] == dict(timeout=0, error=0) for seat in result['seats'])
        hashes[path.name] = hashlib.sha256(raw).hexdigest()
        normalized = {field: value for field, value in game.items() if field != 'cacheHit'}
        signature = hashlib.sha256(json.dumps(normalized, sort_keys=True).encode('utf-8')).hexdigest()
        if key in arms[arm]:
            assert arms[arm][key] == score and signatures[arm][key] == signature
            duplicate_artifacts += 1
            continue
        arms[arm][key] = score
        signatures[arm][key] = signature
    for arm, scores in arms.items():
        assert scores.keys() == expected.keys()
        observed = dict(played=len(scores), wins=sum(value == 1 for value in scores.values()), draws=sum(value == 0.5 for value in scores.values()), score=sum(scores.values()) / len(scores))
        assert observed == stage_report['arms'][arm]
    differences = [sum(arms['candidate'][(seed, seat)] - arms['control'][(seed, seat)] for seat in (0, 1)) / 2 for seed in stage['seeds']]
    count = len(differences)
    mean = sum(differences) / count
    sample_variance = variance(differences)
    unique_probability = math.prod(1 - index / protocol['seedPopulation'] for index in range(count))
    effective_delta = protocol['alpha'] * unique_probability
    logarithm = math.log(2 / effective_delta)
    lower = mean - math.sqrt(2 * sample_variance * logarithm / count) - 14 * logarithm / (3 * (count - 1))
    evidence = stage_report['evidence']
    assert evidence['played'] == games_per_arm and evidence['seedBlocks'] == count
    for field, observed in dict(difference=mean, sampleVariance=sample_variance, lowerBound=lower, conditioningProbability=unique_probability, effectiveDelta=effective_delta).items():
        assert math.isclose(evidence[field], observed, rel_tol=1e-10, abs_tol=1e-12)
    assert evidence['accepted'] is (lower > 0)
    assert report['accepted'] is evidence['accepted']
    assert math.isclose(stage_report['difference'], mean, rel_tol=1e-10, abs_tol=1e-12)
    audit = dict(status='passed', activated=False, rawArtifacts=len(hashes), uniqueGames=sum(len(scores) for scores in arms.values()), duplicateArtifactsExcluded=duplicate_artifacts, duplicateRule='Same policy and task, with identical full output after removing only cacheHit; counted once', gamesPerArm=games_per_arm, seedBlocks=count, protocolSha256=hashlib.sha256(protocol_bytes).hexdigest(), auditorSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), deploymentPolicySha256=protocol['deploymentPolicySha256'], difference=mean, lowerBound=lower, accepted=lower > 0, scope='Chronomon exact deck against 12 fixed confirmation opponents using sourceDp 0.2, both seats; not a general human or all-opponent strength claim')
    for name, value in (('independent-raw-sha256.json', hashes), ('independent-raw-audit.json', audit)):
        temporary = root / f'{name}.tmp'
        temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
        temporary.replace(root / name)
    print(json.dumps(audit), flush=True)


if __name__ == '__main__':
    main()
